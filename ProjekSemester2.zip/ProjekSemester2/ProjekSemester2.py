class Anggota:
    def __init__(self, no_hp='', nama=''):
        self.no_hp = no_hp
        self.nama = nama
        self.next = None

class AnggotaMembayar:
    def __init__(self, no_hp='', nama='', jumlah=0):
        self.no_hp = no_hp
        self.nama = nama
        self.jumlah = jumlah
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def push(self, data):
        data.next = self.top
        self.top = data

    def pop(self):
        if not self.top:
            return None
        popped = self.top
        self.top = self.top.next
        return popped

    def is_empty(self):
        return self.top is None

    def print_stack(self):
        current = self.top
        while current:
            print(f'No HP Anggota: {current.no_hp}')
            print(f'Nama Anggota: {current.nama}')
            if hasattr(current, 'jumlah'):
                print(f'Jumlah yang disetor: Rp{current.jumlah}')
            print('=============================')
            current = current.next

    def sort_by_jumlah(self):
        sorted_list = self.get_list()
        sorted_list.sort(key=lambda x: x.jumlah, reverse=True)
        self.top = None
        for item in sorted_list:
            self.push(item)

    def get_list(self):
        result = []
        current = self.top
        while current:
            result.append(current)
            current = current.next
        return result

DataAnggota = []
DataAnggotaMembayar = Stack()
RiwayatUpdate = Stack()

def menu():
    print('.............................................')
    print('           - Buku Arisan Digital -           ')
    print('=============================================')
    print('1. Tambah Anggota Baru')
    print('2. Tampilkan Daftar Anggota')
    print('3. Update Data Anggota')
    print('4. Tampilkan Anggota Arisan yang Telah Membayar ')
    print('5. Tampilkan Riwayat Update Terakhir')
    print('6. Tutup')
    print('=============================================')
    
    pilih = int(input('Masukkan pilihan anda: '))
    if pilih == 1:
        tambah_anggota()
        menu()
    elif pilih == 2:
        tampil_anggota()
        input('Kembali ke Menu Utama')
        menu()
    elif pilih == 3:
        update_anggota()
        menu()
    elif pilih == 4:
        tampil_anggota_membayar()
        input('\n\nKembali ke Menu Utama')
        menu()
    elif pilih == 5:
        tampil_riwayat_update()
        input('\n\nKembali ke Menu Utama')
        menu()
    elif pilih == 6:
        print('=============================')
        print('          ARISAN KOMPLEKS    ')
        print('  Terima kasih telah berkunjung')
        exit()

def tampil_anggota():
    print('=============================')
    print('        DAFTAR ANGGOTA       ')
    print('=============================')
    sorted_anggota = sorted(DataAnggota, key=lambda x: x.nama)
    for data in sorted_anggota:
        print(f'No HP Anggota: {data.no_hp}')
        print(f'Nama Anggota: {data.nama}')
        print('=============================')


def tambah_anggota():
    ulang = 'ya'
    while ulang.lower() in ('ya', 'tidak'):
        anggota_baru = Anggota()
        print('INPUT DATA ANGGOTA BARU')
        anggota_baru.no_hp = input('Masukkan No HP Anggota (hanya angka): ')
        while not anggota_baru.no_hp.isdigit():
            print('Masukkan harus berupa angka.')
            anggota_baru.no_hp = input('Masukkan No HP Anggota (hanya angka): ')
        anggota_baru.nama = input('Masukkan Nama Anggota: ')
        DataAnggota.append(anggota_baru)
        simpan_data_anggota()
        
        setor = input('Apakah Anda ingin menyetor uang arisan (ya/tidak)? ')
        if setor.lower() == 'ya':
            jumlah = int(input('Masukkan jumlah uang yang disetor: '))
            tambah_anggota_membayar(anggota_baru.no_hp, anggota_baru.nama, jumlah)

        ulang = input('Apakah Anda ingin menambah anggota (ya/tidak): ')
        if ulang.lower() != 'ya':
            break
def update_anggota():
    while True:
        try:
            index_update = -1
            tampil_anggota()
            nama_edit = input('Input Nama Anggota yang akan di update (atau tekan 1 untuk kembali ke menu utama): ')
            if nama_edit == '1':
                break
            for a in range(len(DataAnggota)):
                if nama_edit == DataAnggota[a].nama:
                    index_update = a
                    break
            if index_update > -1:
                print("Data anggota berhasil ditemukan")
                anggota_lama = DataAnggota[index_update]
                anggota_baru = Anggota()
                anggota_baru.no_hp = input('Masukkan No HP Anggota (hanya angka): ')
                while not anggota_baru.no_hp.isdigit():
                    print('Masukkan harus berupa angka.')
                    anggota_baru.no_hp = input('Masukkan No HP Anggota (hanya angka): ')
                anggota_baru.nama = input('Masukkan Nama Anggota: ')
                
                # Simpan data anggota lama ke stack riwayat update
                RiwayatUpdate.push(Anggota(anggota_lama.no_hp, anggota_lama.nama))
                simpan_riwayat_update()

                DataAnggota[index_update] = anggota_baru
                simpan_data_anggota()
                print('Berhasil menyimpan data anggota')

                # Update atau tambah data arisan yang sudah dibayar
                setor = input('Apakah Anda ingin menyetor uang tambahan (ya/tidak)? ')
                if setor.lower() == 'ya':
                    jumlah = int(input('Masukkan jumlah uang tambahan yang disetor: '))
                    tambah_anggota_membayar(anggota_baru.no_hp, anggota_baru.nama, jumlah)

                print("Data berhasil diupdate")
            else:
                print('Nama Anggota tidak ditemukan')
        except ValueError:
            print("Input tidak valid. Silakan masukkan Nama anggota yang benar.")
        input('Tekan Enter untuk melanjutkan...')

def simpan_data_anggota():
    with open('dataanggota.txt', 'w') as file:
        for anggota in DataAnggota:
            file.write(f'{anggota.no_hp},{anggota.nama}\n')

def muat_data_anggota():
    try:
        with open('dataanggota.txt', 'r') as file:
            for line in file:
                no_hp, nama = line.strip().split(',')
                DataAnggota.append(Anggota(no_hp, nama))
    except FileNotFoundError:
        print('File dataanggota.txt tidak ditemukan. Memulai dengan data kosong.')

def tambah_anggota_membayar(no_hp, nama, jumlah):
    anggota_membayar = AnggotaMembayar(no_hp, nama, jumlah)
    DataAnggotaMembayar.push(anggota_membayar)
    simpan_data_anggota_membayar()

def tampil_anggota_membayar():
    print('=============================')
    print(' DAFTAR ANGGOTA YANG MEMBAYAR ')
    print('=============================')
    if DataAnggotaMembayar.is_empty():
        print('Belum ada anggota yang membayar.')
    else:
        DataAnggotaMembayar.sort_by_jumlah()  # Mengurutkan berdasarkan jumlah yang disetor
        DataAnggotaMembayar.print_stack()

def tampil_riwayat_update():
    print('=============================')
    print('  RIWAYAT UPDATE TERAKHIR ')
    print('=============================')
    if RiwayatUpdate.is_empty():
        print('Belum ada update yang tercatat.')
    else:
        RiwayatUpdate.print_stack()

def simpan_data_anggota_membayar():
    with open('datamembayar.txt', 'w') as file:
        current = DataAnggotaMembayar.top
        while current:
            file.write(f'{current.no_hp},{current.nama},{current.jumlah}\n')
            current = current.next

def muat_data_anggota_membayar():
    try:
        with open('datamembayar.txt', 'r') as file:
            for line in file:
                no_hp, nama, jumlah = line.strip().split(',')
                anggota_membayar = AnggotaMembayar(no_hp, nama, int(jumlah))
                DataAnggotaMembayar.push(anggota_membayar)
    except FileNotFoundError:
        print('File datamembayar.txt tidak ditemukan. Memulai dengan data kosong.')

def simpan_riwayat_update():
    with open('riwayatupdate.txt', 'w') as file:
        current = RiwayatUpdate.top
        while current:
            file.write(f'{current.no_hp},{current.nama}\n')
            current = current.next

def muat_riwayat_update():
    try:
        with open('riwayatupdate.txt', 'r') as file:
            for line in file:
                no_hp, nama = line.strip().split(',')
                RiwayatUpdate.push(Anggota(no_hp, nama))
    except FileNotFoundError:
        print('File riwayatupdate.txt tidak ditemukan. Memulai dengan data kosong.')

muat_data_anggota()
muat_data_anggota_membayar()
muat_riwayat_update()
menu()
